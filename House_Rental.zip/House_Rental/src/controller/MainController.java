package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import service.UserService;

@Controller
public class MainController {
	
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/loginsuccess", method = RequestMethod.POST)
	public ModelAndView executeLogin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("log") User user) {

		ModelAndView model = null;
		try {
			boolean isValidUser = userService.isValidUser(user.getUsername(),
					user.getPassword());
			if (isValidUser) {
				System.out.println("User Login Successful");
				//request.setAttribute("loggedInUser", user.getPatientUserName());
				model = new ModelAndView("Welcome");
			} else {
				model = new ModelAndView("new_home");
				model.addObject("User", user);
				request.setAttribute("message", "Invalid credentials!!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}
	
	


	@RequestMapping(value = {"/new_home","/"}, method = RequestMethod.GET)
	public ModelAndView home() {

		ModelAndView mv = new ModelAndView("new_home");

		return mv;

	}

	@RequestMapping(value = "/loginhome", method = RequestMethod.GET)
	public ModelAndView homew() {

		ModelAndView mv = new ModelAndView("loginhome");

		return mv;

	}
//testin login for  sample dlete later
	@RequestMapping(value = "/NewLogin", method = RequestMethod.GET)
	public ModelAndView homelogin() {

		ModelAndView mv = new ModelAndView("NewLogin");

		return mv;

	}
	@RequestMapping(value = "/loginsuccess", method = RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("reg") User user) {

		ModelAndView mv = new ModelAndView("registration");

		return mv;

	}

	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registeruser(@ModelAttribute("user") bean.User userbean, BindingResult result) {
		User user = prepareModel(userbean);
		userService.addUser(user);
		return new ModelAndView("Welcome");

	}

	private User prepareModel(bean.User userbean) {
		User user = new User();
		System.out.println("beans data is " + userbean.toString());
		user.setAddress(userbean.getAddress());
		user.setDob(userbean.getDob());
		user.setFirstName(userbean.getFirstName());
		user.setEmail(userbean.getEmail());
		user.setGender(userbean.getGender());
		user.setLastName(userbean.getLastName());
		user.setMob_no(userbean.getMob_no());
		user.setUsername(userbean.getUsername());
		user.setPassword(userbean.getPassword());
		System.out.println("patient data is " + user.toString());
		return user;
	}
	
	
	@RequestMapping(value = "/forgotpassword", method = RequestMethod.GET)
	public ModelAndView passwordReset() {

		ModelAndView mv = new ModelAndView("forgotpassword");

		return mv;

	}

	/*@RequestMapping(value = "/loginsuccess", method = RequestMethod.POST)
	public ModelAndView loginMethod(@RequestParam("username") String username,
			@RequestParam("password") String password) {

		LoginService loginservice = new LoginService();

		boolean flag;
		
		System.out.println("before validating");

		flag = loginservice.validate(username, password);
		
		System.out.println("after validating");
		if (flag) {

			ModelAndView mv = new ModelAndView("loginhome");
			return mv;

		}

		ModelAndView mv2 = new ModelAndView("new_home");
		mv2.addObject("msg", "entered wrong username and password!.");
		return mv2;

	}

	@RequestMapping(value = "/registrationsuccess", method = RequestMethod.POST)
	public ModelAndView registerMethod(
			@RequestParam("userName") String userName,
			@RequestParam("password") String password,
			@RequestParam("contactNumber") int contactNumber,
			@RequestParam("emailid") String emailid,
			@RequestParam("balence") int balence) {

		RegistrationService register = new RegistrationService();
		register.register(userName, password, contactNumber, emailid, balence);
		ModelAndView mv = new ModelAndView("registrationsuccess");
		return mv;
	}*/

}
