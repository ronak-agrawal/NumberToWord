package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class Owner {
	@Id
	 @Column(name="ownerid")
	@GenericGenerator(name = "id", strategy = "id_gen.UserIdGenerator")
	@GeneratedValue(generator = "id")  
	 //@GeneratedValue(strategy=GenerationType.AUTO)
    private String ownerid;
	@Column(name="firstname")
    private String firstName;
	@Column(name="lastname")
    private String lastName;
	@Column(name="dob")
    private Date dob;
	@Column(name="email")
    private String email;
	@Column(name="password")
    private String password;
	@Column(name="gender")
    private String gender;
	@Column(name="mob_no")
    private Long mob_no;
	@Column(name="address")
    private String address;
	
	
	
	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "Owner_User", joinColumns = { @JoinColumn(name = "ownerid") }, inverseJoinColumns = { @JoinColumn(name = "userid") })
	private List<User> userObj1 = new ArrayList<User>();
	
	@ManyToOne
	@JoinColumn(name="houseid")
	private House houseObj1;

	
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getMob_no() {
		return mob_no;
	}
	public void setMob_no(Long mob_no) {
		this.mob_no = mob_no;
	}
	
    public String getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Date getDob() {
        return dob;
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
	@Override
	public String toString() {
		return "Owner [ownerid=" + ownerid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", email="
				+ email + ", gender=" + gender + ", mob_no=" + mob_no
				+ ", address=" + address + "]";
	}
    
}