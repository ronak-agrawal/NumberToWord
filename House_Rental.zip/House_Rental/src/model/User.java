package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class User {
	@Id
	 @Column(name="userid")
	@GenericGenerator(name = "id", strategy = "id_gen.UserIdGenerator")
	@GeneratedValue(generator = "id")  
	// @GeneratedValue(strategy=GenerationType.AUTO)
    private String userid;
	@Column(name="firstname")
    private String firstName;
	@Column(name="lastname")
    private String lastName;
	@Column(name="dob")
    private Date dob;
	@Column(name="email")
    private String email;
	@Column(name="username",unique = true)
    private String username;
	@Column(name="password")
    private String password;
	@Column(name="gender")
    private String gender;
	@Column(name="mob_no")
    private int mob_no;
	@Column(name="address")
    private String address;
	
	
	@ManyToMany(mappedBy = "userObj")
	private List<Broker> BrokerObj = new ArrayList<Broker>();
	
	@ManyToMany(mappedBy = "userObj1")
	private List<Owner> OwnerObj = new ArrayList<Owner>();
	
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMob_no() {
		return mob_no;
	}
	public void setMob_no(int mob_no) {
		this.mob_no = mob_no;
	}
	public String getUserid() {
        return userid;
    }
    public void setUserid(String userid) {
        this.userid = userid;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Date getDob() {
        return dob;
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "User [userid=" + userid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", email="
				+ email + ", username=" + username + ", password=" + password
				+ ", gender=" + gender + ", mob_no=" + mob_no + ", address="
				+ address + "]";
	}
	
    
}