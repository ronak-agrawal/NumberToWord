package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.mysql.jdbc.Blob;

@Entity
@Table
public class House {
	@Id
	 @Column(name="houseid")
	@GenericGenerator(name = "id", strategy = "id_gen.PropIdGenerator")
	@GeneratedValue(generator = "id")  
	//@GeneratedValue(strategy=GenerationType.AUTO)
    private String houseid;
	@Column(name="house_no")
    private int house_no;
	@Column(name="society")
    private String society;
	@Column(name="street")
    private String street;
	@Column(name="landmark")
    private String landmark;
	@Column(name="city")
    private String city;
	@Column(name="state")
    private String state;
	@Column(name="surface_area")
    private double surface_area;
	@Column(name="type")
    private String type;
	@Column(name="rent")
    private double rent;
	@Lob
	@Column(name="image")
    private Blob image ;
	
	@ManyToMany(mappedBy = "houseObj")
	private List<Broker> BrokerObj = new ArrayList<Broker>();

	@OneToMany(mappedBy = "houseObj1")
	private Set<Owner> OwnerObj;
	
	public String getHouseid() {
		return houseid;
	}
	public void setHouseid(String houseid) {
		this.houseid = houseid;
	}
	public int getHouse_no() {
		return house_no;
	}
	public void setHouse_no(int house_no) {
		this.house_no = house_no;
	}
	public String getSociety() {
		return society;
	}
	public void setSociety(String society) {
		this.society = society;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getSurface_area() {
		return surface_area;
	}
	public void setSurface_area(double surface_area) {
		this.surface_area = surface_area;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getRent() {
		return rent;
	}
	public void setRent(double rent) {
		this.rent = rent;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	
	@Override
	public String toString() {
		return "House [houseid=" + houseid + ", house_no=" + house_no
				+ ", society=" + society + ", street=" + street + ", landmark="
				+ landmark + ", city=" + city + ", state=" + state
				+ ", surface_area=" + surface_area + ", type=" + type
				+ ", rent=" + rent + "]";
	}
}