package bean;

import java.util.Date;

public class Broker {
	
    private String brokerid;
    private String firstName;
    private String lastName;
    private Date dob;
    private String email;
    private String password;
    private String gender;
    private Long mob_no;
    private String address;
	
    
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getMob_no() {
		return mob_no;
	}
	public void setMob_no(Long mob_no) {
		this.mob_no = mob_no;
	}
	
	public String getBrokerid() {
		return brokerid;
	}
	public void setBrokerid(String brokerid) {
		this.brokerid = brokerid;
	}
	public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Date getDob() {
        return dob;
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
	@Override
	public String toString() {
		return "Broker [brokerid=" + brokerid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", email="
				+ email + ", gender=" + gender + ", mob_no=" + mob_no
				+ ", address=" + address + "]";
	}
    
}