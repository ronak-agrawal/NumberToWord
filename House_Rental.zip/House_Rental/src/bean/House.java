package bean;


import com.mysql.jdbc.Blob;

public class House {
	
    private String houseid;
    private int house_no;
    private String society;
    private String street;
    private String landmark;
    private String city;
    private String state;
    private double surface_area;
    private String type;
    private double rent;
    private Blob image ;
	
	public String getHouseid() {
		return houseid;
	}
	public void setHouseid(String houseid) {
		this.houseid = houseid;
	}
	public int getHouse_no() {
		return house_no;
	}
	public void setHouse_no(int house_no) {
		this.house_no = house_no;
	}
	public String getSociety() {
		return society;
	}
	public void setSociety(String society) {
		this.society = society;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getSurface_area() {
		return surface_area;
	}
	public void setSurface_area(double surface_area) {
		this.surface_area = surface_area;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getRent() {
		return rent;
	}
	public void setRent(double rent) {
		this.rent = rent;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	
	@Override
	public String toString() {
		return "House [houseid=" + houseid + ", house_no=" + house_no
				+ ", society=" + society + ", street=" + street + ", landmark="
				+ landmark + ", city=" + city + ", state=" + state
				+ ", surface_area=" + surface_area + ", type=" + type
				+ ", rent=" + rent + "]";
	}
}