package dao;

import java.util.List;

import bean.House;

public interface HouseDao {
	    public void addHouse(House house);
	    public void deleteHouse(int houseid);
	    public void updateHouse(House house);
	    public List<House> getAllHouses();
	    public House getHousesById(String houseid);
}
