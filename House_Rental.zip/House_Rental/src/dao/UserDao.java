package dao;

import java.sql.SQLException;
import java.util.List;

import model.User;

public interface UserDao {
	    public void addUser(User user);
	    public void deleteUser(int userid);
	    public void updateUser(User user);
	    public List<User> getAllUsers();
	    public User getUserByUsername(String username);
	    public boolean isValidUser(String patientUserName, String patientPassword) throws SQLException;
}
