package dao;

import java.util.List;

import bean.Owner;

public interface OwnerDao {
	    public void addOwner(Owner owner);
	    public void deleteOwner(int ownerid);
	    public void updateOwner(Owner owner);
	    public List<Owner> getAllOwners();
	    public Owner getOwnersById(String ownerid);
}
