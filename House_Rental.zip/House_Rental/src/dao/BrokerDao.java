package dao;

import java.util.List;

import bean.Broker;

public interface BrokerDao {

	    public void addBroker(Broker broker);
	    public void deleteBroker(int brokerid);
	    public void updateBroker(Broker broker);
	    public List<Broker> getAllBrokers();
	    public Broker getBrokersById(String brokerid);
}
