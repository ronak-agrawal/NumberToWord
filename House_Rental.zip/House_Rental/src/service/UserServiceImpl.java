package service;

import java.sql.SQLException;

import model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.UserDao;

//@Component
@Service
class UserServiceImpl implements UserService{
	
	@Autowired
	private UserDao useDAO;
	
	@Transactional
	public boolean isValidUser(String patientUserName, String patientPassword) throws SQLException
	{
		return useDAO.isValidUser(patientUserName, patientPassword);
	}

	@Transactional
	public void addUser(User p) {
		useDAO.addUser(p);
	}

	
	


}
