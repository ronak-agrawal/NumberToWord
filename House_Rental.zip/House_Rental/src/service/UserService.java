package service;

import java.sql.SQLException;

import model.User;



public interface UserService {

	public void addUser(User p);
    public boolean isValidUser(String patientUserName, String patientPassword) throws SQLException;


}
