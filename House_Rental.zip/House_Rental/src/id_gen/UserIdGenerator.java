package id_gen;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

import util.HibernateUtil;
 
public class UserIdGenerator implements IdentifierGenerator {
 int custid=0;
    public int generateCustId() {
    	SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		 custid = ((Long)session.createQuery("select count(*) from User").uniqueResult()).intValue();
		System.out.println("custid is "+custid);
		 custid++;
    	return custid;
    }
 
    @Override
    public Serializable generate(SessionImplementor si, Object o) throws HibernateException {
 
        Date date = new Date();
         System.out.println(date);
        Calendar calendar = Calendar.getInstance();
        return "user_" + this.generateCustId() + "_" + calendar.get(Calendar.DATE)+ "/" + calendar.get(Calendar.MONTH)+ "/" + calendar.get(Calendar.YEAR);
 
    }
}