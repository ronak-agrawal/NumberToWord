package daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import model.User;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import util.HibernateUtil;

import com.mysql.jdbc.PreparedStatement;

import dao.UserDao;

public class UserDaoImpl implements UserDao{
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

    public void addUser(User user) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.save(user);
            session.getTransaction().commit();
            logger.info("User saved successfully, User Details=" + user.toString());
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    public void deleteUser(int userid) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            User user = (User) session.load(User.class, new Integer(userid));
            session.delete(user);
            session.getTransaction().commit();
            logger.info("User "+ user.getUsername()+" deleted successfully" );
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    public void updateUser(User user) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.update(user);
            session.getTransaction().commit();
            logger.info("User "+ user.getUsername()+" updated successfully" );

        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    @SuppressWarnings("unchecked")
	public List<User> getAllUsers() {
        List<User> users = new ArrayList<User>();
        @SuppressWarnings("unused")
		Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            users = session.createQuery("from User").list();
            logger.info("All Users loaded successfully" );

        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return users;
    }

    public User getUserByUsername(String username) {
        User user = null;
        @SuppressWarnings("unused")
		Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            String queryString = "from User where username = :name";
            Query query = session.createQuery(queryString);
            query.setString("name", username);
            user = (User) query.uniqueResult();
            logger.info("User "+ user.getUsername()+" loaded successfully" );

        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return user;
    }
    
    
    @Autowired
	private DataSource dataSource;
    
    public boolean isValidUser(String patientUserName, String patientPassword) throws SQLException
    {
    	String query = "Select count(1) from User where username = ? and password = ?";
		PreparedStatement pstmt = (PreparedStatement) dataSource.getConnection().prepareStatement(query);
		pstmt.setString(1, patientUserName);
		pstmt.setString(2, patientPassword);
		ResultSet resultSet = pstmt.executeQuery();
		if(resultSet.next())
		    return (resultSet.getInt(1) > 0);
        else
           return false;
    	
    }
    
}