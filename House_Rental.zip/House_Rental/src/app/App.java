package app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import model.User;

import org.hibernate.exception.ConstraintViolationException;

import daoImpl.UserDaoImpl;

public class App {

    public static void main(String[] args) {
        UserDaoImpl dao = new UserDaoImpl();

        // Add new user
        User user = new User();
        user.setFirstName("ronak");
        user.setLastName("agrawal");
        try {
            Date dob = new SimpleDateFormat("dd-MM-yyyy").parse("01-02-1986");
            user.setDob(dob);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        user.setEmail("aaaa@example.com");
        user.setGender("male");
        user.setUsername("ronak11241");
        user.setMob_no(12233233);
        user.setPassword("123");
        
        
        try {
        	dao.addUser(user);
        } catch (final ConstraintViolationException e) {
        	System.out.println("Username already exists...");

        }
        
        
//
//        // Update user
       /* user.setEmail("cvcvc@updatedJdbc.com");
        dao.updateUser(user);*/

        // Delete user
        //dao.deleteUser(2);

       /* // Get all users
        for (User iter : dao.getAllUsers()) {
            System.out.println(iter);
        }*/

        // Get user by username
        System.out.println(dao.getUserByUsername("ronak1"));

        
        // Get all user 
        System.out.println(dao.getAllUsers());

        /*try {
            DbUtil.getConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }*/
    }

}